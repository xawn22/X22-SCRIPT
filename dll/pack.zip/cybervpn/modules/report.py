from cybervpn import *
import requests
import subprocess
@bot.on(events.CallbackQuery(data=b'report'))
async def create_trojan(event):
    user_id = str(event.sender_id)
    async def create_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Kendala Apa Yang Anda Alami ?**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        cmd = f'printf "%s\n" "{user}" "{user_id}" | report'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error

        msg = f"""
**Terimakasih Laporan Telah Diterima**
**Kami Segera Memperbaiki Kendala Nya**
**Mohon Menunggu Balasan Dari Kami**
"""
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_trojan_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')