from cybervpn import *
import subprocess
import datetime as DT
import random

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    async def trial_ssh_(event):
        user = "trialX" + str(random.randint(100, 1000))
        pw = "1"
        exp = "1"
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
 **Thank You For Using Our Service**
┌──────────────────┐
│👤User : {user.strip()}
│🔐Pass : {pw.strip()}
│🗓️Expiry : {later}
└──────────────────┘
┌──────────────────┐
│HOST : {DOMAIN}
│OPENSSH : 22
│SSH WS NTLS : 80
│SSH WS TLS : 443
│SSH UDP : 1-65535
│SSH OHP : 8181
│DROPBEAR : 443, 143, 109
│STUNNEL : 443, 445, 777
│SQUID PROXY : 3128, 8080
│OVPN WS : 2086
│OVPN TCP : 1194
│OVPN UDP : 2200
│OVPN SSL : 990
│BADVPN : 7100 - 7300
└──────────────────┘
┌──────────────────┐
│ **📥OpenVPN File**
│ http://{DOMAIN}:89/tcp.ovpn
│ http://{DOMAIN}:89/udp.ovpn
│ http://{DOMAIN}:89/ssl.ovpn
└──────────────────┘
┌──────────────────┐
│ **📝Payload SSH Websocket**
└──────────────────┘
GET / HTTP/1.1 [crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]
"""
         
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trial_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak...!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')

