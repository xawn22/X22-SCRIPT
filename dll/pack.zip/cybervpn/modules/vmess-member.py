from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time

# ... (kode lainnya)

@bot.on(events.CallbackQuery(data=b'create-vmess-member'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                    [Button.inline("15 Hari", b"15"),
                    Button.inline("30 Hari", b"30")],
                    [Button.inline("60 Hari", b"60"),
                    Button.inline("90 Hari", b"90")]
            ])
            exp = (await exp_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

            # Menentukan harga berdasarkan pilihan user
            if exp == "15":
                harga = 3000
            elif exp == "30":
                harga = 6000
            elif exp == "60":
                harga = 12000
            elif exp == "90":
                harga = 18000
            else:
                await event.respond("**✘ Pilihan tidak valid.**")
                return

        # Panggil fungsi untuk memproses saldo pengguna
        saldo_tercukupi = await process_user_balance_vmess(event, user_id, harga)
        
        if not saldo_tercukupi:  # Jika saldo tidak mencukupi, hentikan proses
            return

        cmd = f'printf "%s\n" "{user}" "{exp}" | add-vmess'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
**Thank You For Using Our Services**
┌──────────────────┐
│🌟XRAY VMESS ACCOUNT🌟
└──────────────────┘
┌──────────────────┐
│👤Remarks : {z["ps"]}
│🌐Domain : {z["add"]}
│⚙️Port HTTP : 8880
│⚙️Port TLS : 8443
│📦Alter ID : 0
│🔐Security : Auto
│📡Network : Ws
│📝Path : /v2ray
│🗓️Expiry : {later}
└──────────────────┘
┌──────────────────┐
│🆔 : __{z["id"]}__
└──────────────────┘
┌──────────────────┐
│ ⚙️URL VMESS HTTP⚙️
└──────────────────┘
```{b[1].strip("'").replace(" ","")}```
┌──────────────────┐
│ ⚙️URL VMESS TLS⚙️
└──────────────────┘
```{b[0].strip("'").replace(" ","")}```
        """
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess-member'))
async def trial_vmess(event):
    async def trial_vmess_(event):

        # output cmd
        cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" | add-vmess'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=1)  # You may need to adjust this, as "exp" is not defined in the scope
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)
        msg = f"""
**Thank You For Using Our Services**
┌──────────────────┐
│🌟XRAY VMESS ACCOUNT🌟
└──────────────────┘
┌──────────────────┐
│👤Remarks : {z["ps"]}
│🌐Domain : {z["add"]}
│⚙️Port HTTP : 8880
│⚙️Port TLS : 8443
│📦Alter ID : 0
│🔐Security : Auto
│📡Network : Ws
│📝Path : /v2ray
│🗓️Expiry : 2 Jam
└──────────────────┘
┌──────────────────┐
│🆔 : __{z["id"]}__
└──────────────────┘
┌──────────────────┐
│ ⚙️URL VMESS HTTP⚙️
└──────────────────┘
```{b[1].strip("'").replace(" ","")}```
┌──────────────────┐
│ ⚙️URL VMESS TLS⚙️
└──────────────────┘
```{b[0].strip("'").replace(" ","")}```
        """
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trial_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess-member'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'cek-ws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
╔═╗─╔╗──────────╔═╦═╗
║╔╬═╣╠╗╔═╦═╦══╦═╣═╣═╣
║╚╣╩╣═╣╚╗║╔╣║║║╩╬═╠═║
╚═╩═╩╩╝─╚═╝╚╩╩╩═╩═╩═╝
{z}

**Shows Logged In Users Vmess**
""", buttons=[[Button.inline("‹ Main Menu ›", "vmess-member")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



## CEK member VMESS
@bot.on(events.CallbackQuery(data=b'cek-member-member'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bash cek-mws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ Main Menu ›", "vmess-member")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')





@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | delws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted {user} **"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vmess-member'))
async def ren_vmess(event):
    async def ren_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Perhatian username pastikan sudah benar.!!**')
            await event.respond('**Username :**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                    [Button.inline("15 Hari", b"15"),
                    Button.inline("30 Hari", b"30")],
                    [Button.inline("60 Hari", b"60"),
                    Button.inline("90 Hari", b"90")]
            ])
            exp = (await exp_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

            # Menentukan harga berdasarkan pilihan user
            if exp == "15":
                harga = 3000
            elif exp == "30":
                harga = 6000
            elif exp == "60":
                harga = 12000
            elif exp == "90":
                harga = 18000
            else:
                await event.respond("**✘ Pilihan tidak valid.**")
                return

        # Panggil fungsi untuk memproses saldo pengguna
        saldo_tercukupi = await process_user_balance_vmess(event, user_id, harga)
        
        if not saldo_tercukupi:  # Jika saldo tidak mencukupi, hentikan proses
            return

        cmd = f'printf "%s\n" "{user}" "{exp}" | renew-vmess'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**{a}**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await ren_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

		
@bot.on(events.CallbackQuery(data=b'vmess-member'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("Create VMess", "create-vmess-member"),
            Button.inline("Renew VMess", "renew-vmess-member")],
            [Button.inline("Trial VMess", "trial-vmess-member")],
            [Button.inline("🔙Kembali", "menu")],
]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━
       **🌟VMESS MENU🌟**
━━━━━━━━━━━━━━━━━━━
`- VMess None TLS`
`- VMess TLS`
`- Port None TLS 8880`
`- Port TLS 8443`
`- Max Login 2 Device`

**📝PRICE LIST**
`- Rp3.000 = 15 Hari`
`- Rp6.000 = 30 Hari`
`- Rp12.000 = 60 Hari`
`- Rp18.000 = 90 Hari`

**🎉Happy Shoping🎉**

"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



