from cybervpn import *
from telethon import events, Button
import requests

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    sender = await event.get_sender()
    user_id = str(event.sender_id)
    sender_username = sender.username

    if check_user_registration(user_id):
        try:
            x = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            o = 'bash /usr/bin/menu-admin'
            z = subprocess.check_output(o, shell=True).decode("utf-8")
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("𝙈𝙚𝙣𝙪 𝙎𝙎𝙃", "ssh"),
                    Button.inline("𝙈𝙚𝙣𝙪 𝙑𝙈𝙚𝙨𝙨", "vmess-member")],
                    [Button.inline("𝙈𝙚𝙣𝙪 𝙑𝙇𝙚𝙨𝙨", "vless-member"),
                    Button.inline("𝙈𝙚𝙣𝙪 𝙏𝙧𝙤𝙟𝙖𝙣", "trojan-member")],
                    [Button.inline("⚠️Laporkan Kendala⚠️", "report")],
                    [Button.inline("🏧TopUp Saldo🏧", "topup")],
                ]

                member_msg = f"""
```👋𝙃𝙖𝙞𝙞𝙞... {sender_username}```
𝙎𝙚𝙡𝙖𝙢𝙖𝙩 𝘿𝙖𝙩𝙖𝙣𝙜 𝘿𝙞 𝙋𝙖𝙣𝙚𝙡 𝙍𝙚𝙨𝙚𝙡𝙡𝙚𝙧 𝙆𝙖𝙢𝙞

`📑TIME :` {x["timezone"]}
`📡HOST :` {DOMAIN}
`🌐ISP  :` {x["isp"]}
`🌍CITY :` {x["country"]}, {x["city"]}

`👤Username :` @{sender_username}
`👤User ID  :` {user_id}
`💰Saldo ku :` Rp.{saldo_aji}
`
⚙️Layanan VMess  : {get_xray()}
⚙️Layanan VLess  : {get_xray()}
⚙️Layanan Trojan : {get_trojan()}
⚙️Layanan SSH    : {get_ssh()}
`
**🤖Manage By @{sender_username}**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
               [Button.inline(" 𝗦𝗦𝗛 ","ssh"),
Button.inline(" 𝗩𝗠𝗘𝗦𝗦 ","vmess")],
[Button.inline(" 𝗧𝗥𝗢𝗝𝗔𝗡 ","trojan"),
Button.inline(" 𝗩𝗟𝗘𝗦𝗦 ","vless")],
[Button.inline(" 𝗙𝗘𝗔𝗧𝗨𝗥𝗘 𝗠𝗔𝗡𝗔𝗚𝗘 ","setting")]]	

                admin_msg = f"""
{z}
```🏧SISA SALDO KU : Rp {saldo_aji}
📝TOTAL MEMBER  : {get_user_count()}```
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```⚠️ID ANDA BELUM TERDAFTAR⚠️```',
            buttons=[[(Button.inline("❌TIDAK DI IZINKAN❌", "registrasi"))]]
        )

