#!/bin/bash
clear
grep -E "^### " "/etc/trojan-go/akun.conf" | cut -d ' ' -f 2 | sort | uniq | nl