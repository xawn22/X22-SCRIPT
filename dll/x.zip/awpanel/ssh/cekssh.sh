#!/bin/bash
if [ -e "/var/log/auth.log" ]; then
    LOG="/var/log/auth.log"
fi
if [ -e "/var/log/secure" ]; then
    LOG="/var/log/secure"
fi

data=($(ps aux | grep -i dropbear | awk '{print $2}'))
echo -e "**==Dropbear User Login / Online==**"
echo -e "**•─────────────────────•**"
echo -e "**ID   |   Username   |   IP Address**"
echo -e "**•─────────────────────•**"
cat $LOG | grep -i dropbear | grep -i "Password auth succeeded" >/tmp/login-db.txt
for PID in "${data[@]}"; do
    cat /tmp/login-db.txt | grep "dropbear\[$PID\]" >/tmp/login-db-pid.txt
    NUM=$(cat /tmp/login-db-pid.txt | wc -l)
    USER=$(cat /tmp/login-db-pid.txt | awk '{print $10}')
    IP=$(cat /tmp/login-db-pid.txt | awk '{print $12}')
    if [ $NUM -eq 1 ]; then
        echo "__${PID} - ${USER} - ${IP}__"
    fi
done
echo ""
echo -e "**==OpenSSH User Login / Online==**"
echo -e "**•─────────────────────•**"
echo -e "**ID   |   Username   |   IP Address**"
echo -e "**•─────────────────────•**"
cat $LOG | grep -i sshd | grep -i "Accepted password for" >/tmp/login-db.txt
data=($(ps aux | grep "\[priv\]" | sort -k 72 | awk '{print $2}'))

for PID in "${data[@]}"; do
    cat /tmp/login-db.txt | grep "sshd\[$PID\]" >/tmp/login-db-pid.txt
    NUM=$(cat /tmp/login-db-pid.txt | wc -l)
    USER=$(cat /tmp/login-db-pid.txt | awk '{print $9}')
    IP=$(cat /tmp/login-db-pid.txt | awk '{print $11}')
    if [ $NUM -eq 1 ]; then
        echo "__${PID} - ${USER} - ${IP}__"
    fi
done
echo ""
if [ -f "/etc/openvpn/server/openvpn-tcp.log" ]; then
    echo ""
    echo -e "**OpenVPN TCP User Login / Online**"
    echo -e "**•─────────────────────•**"
    echo "Username  |  IP Address  |  Connected"
    echo -e "**•─────────────────────•**"
    cat /etc/openvpn/server/openvpn-tcp.log | grep -w "^CLIENT_LIST" | cut -d ',' -f 2,3,8 | sed -e 's/,/      /g' >/tmp/vpn-login-tcp.txt
    cat /tmp/vpn-login-tcp.txt
fi
echo ""
if [ -f "/etc/openvpn/server/openvpn-udp.log" ]; then
    echo " "
    echo -e "**OpenVPN UDP User Login / Online**"
    echo -e "**•─────────────────────•**"
    echo "Username  |  IP Address  |  Connected"
    echo -e "**•─────────────────────•**"
    
    cat /etc/openvpn/server/openvpn-udp.log | grep -w "^CLIENT_LIST" | cut -d ',' -f 2,3,8 | sed -e 's/,/      /g' >/tmp/vpn-login-udp.txt
    cat /tmp/vpn-login-udp.txt
fi
