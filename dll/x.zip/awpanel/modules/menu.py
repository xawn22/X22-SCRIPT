from awpanel import *
import socket

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" SSH ","ssh"),
Button.inline(" VMESS ","vmess")],
[Button.inline(" TROJAN ","trojan"),
Button.inline(" VLESS ","vless")],
[Button.inline(" ETC ","setting")]]
	sender = await event.get_sender()
	sender_username = sender.username
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("**⚠️Permission Not Allowed.!!**", alert=True)
		except:
			await event.reply("**⚠️Permission Not Allowed.!!**")
	elif val == "true":
		osk = 'bash /media/awpanel/tambahan/menubot.sh'
		oskuu = subprocess.check_output(osk, shell=True).decode("utf-8")
		msg = f"""
**{oskuu}**

"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
	else:
		await event.respond(f"** You Dont Have Access**")