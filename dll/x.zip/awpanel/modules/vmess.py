from awpanel import *

#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**🔸Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**🔸Masa Aktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" | addws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
#			c = [x.group() for x in re.finditer("Host XrayDNS(.*)",a)]
#			d = [x.group() for x in re.finditer("Pub Key(.*)",a)]
			print(b)
#			print(d)
#			print(c)
#			xx = re.search("Pub Key      :(.*)",d[0]).group(1)
#			xxx = re.search("Host XrayDNS :(.*)",d[0]).group(1)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
__Accounts Created Suuccessfuly__
**×━━━━━━━━━━━━━━━━━━━━━×**
    Xray/Vmess Accounts
**×━━━━━━━━━━━━━━━━━━━━━×**
🌀Remarks     : {z["ps"]}
🌀Domain      : {z["add"]}
🌀Port TLS    : 8443
🌀Port HTTP   : 8880
🌀User ID     : {z["id"]}
🌀Alter ID    : 0
🌀Security    : auto
🌀Network     : ws
🌀Path        : /v2ray
**×━━━━━━━━━━━━━━━━━━━━━×**
🍀Link TLS  : 
`{b[0].strip("'").replace(" ","")}`
**×━━━━━━━━━━━━━━━━━━━━━×**
🍀Link None TLS : 
`{b[1].strip("'").replace(" ","")}`
**×━━━━━━━━━━━━━━━━━━━━━×**
**✅Format OpenClash✅**
__{z["add"]}:89/vmess-{z["ps"]}.txt__
**📆Expiry      : {later}**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		cmd = f'printf "%s\n"| trialws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
__Accounts Created Suuccessfuly__
**×━━━━━━━━━━━━━━━━━━━━━×**
    Xray/Vmess Accounts
**×━━━━━━━━━━━━━━━━━━━━━×**
🌀Remarks     : {z["ps"]}
🌀Domain      : {z["add"]}
🌀Port TLS    : 8443
🌀Port HTTP   : 8880
🌀User ID     : {z["id"]}
🌀Alter ID    : 0
🌀Security    : auto
🌀Network     : ws
🌀Path        : /v2ray
**×━━━━━━━━━━━━━━━━━━━━━×**
🍀Link TLS  : 
`{b[0].strip("'").replace(" ","")}`
**×━━━━━━━━━━━━━━━━━━━━━×**
🍀Link None TLS : 
`{b[1].strip("'").replace(" ","")}`
**×━━━━━━━━━━━━━━━━━━━━━×**
**✅Format OpenClash✅**
__{z["add"]}:89/vmess-{z["ps"]}.txt__
**📆Expiry      : 1 Days**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Vmess**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'showvmess'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'listws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
^_^
{z}
```
**Total all list vmess accounts**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**🔸Username to delete:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | delws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted** `({user})`"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def ren_vmess(event):
	async def ren_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**🔸Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**🔸Masa Aktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" {exp}| renewws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Renewed**  `({user})` **{exp} Days**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ren_vmess_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)
		
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" Trial ","trial-vmess"),
Button.inline(" Create ","create-vmess")],
[Button.inline(" Delete ","delete-vmess"),
Button.inline(" Renew ","renew-vmess")],
[Button.inline(" Member ","showvmess")],
[Button.inline("‹ Back Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**•━━━━━━━━━━━━━━━━━•**
**» 🔵Protocol:** __XRAY VMESS__
**» 🔵Domain:** __{DOMAIN}__
**» 🔵ISP:** __{z["isp"]}__
**» 🔵Country:** __{z["country"]}__
**•━━━━━━━━━━━━━━━━━•**
**( menu xray vmess )**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)