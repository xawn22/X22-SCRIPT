from awpanel import *

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**🔸Username to delete:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | delssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Deleted** (`{user}`)")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**🔸Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**🔸Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**🔸Masa Aktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
__Accounts Created Successfully__ 
**×━━━━━━━━━━━━━━━━━━━━━×**
**🔰Host/IP:** `{DOMAIN}`
**🔰Username:** `{user.strip()}`
**🔰Password:** `{pw.strip()}`
**×━━━━━━━━━━━━━━━━━━━━━×**
**🌀OpenSSH:** `22`
**🌀SSL/TLS:** `445`, `777`, `443`
**🌀Ssh Udp:** `1-65535`
**🌀Ssh Ohp:** `8181`
**🌀Dropbear Ohp:** `8282`
**🌀OpenVpn Ohp:** `8383`
**🌀Dropbear:** `109`,`143`
**🌀WS SSL:** `443`
**🌀WS HTTP:** `80`
**🌀Squid:** `8080`, `3128`
**🌀UDPGW :** `7100-7300`
**×━━━━━━━━━━━━━━━━━━━━━×**
**🍀Payload Ssh Ws🍀**
`GET / HTTP/1.1 [crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**×━━━━━━━━━━━━━━━━━━━━━×**
**🍀File OpenVPN🍀**
__{DOMAIN}:89/udp.ovpn__
__{DOMAIN}:89/ssl.ovpn__
__{DOMAIN}:89/tcp.ovpn__
**×━━━━━━━━━━━━━━━━━━━━━×**
**🗓Expiry:** `{later}`
**×━━━━━━━━━━━━━━━━━━━━━×**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'listssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
**Show All SSH User**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'lockbg'))
async def locked_ssh(event):
	async def locked_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**🔸Username to lock:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | lockssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Locked** (`{user}`)")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await locked_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		user = "trialX"+str(random.randint(100,1000))
		pw = "1"
		exp = "1"
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
__Accounts Created Successfully__ 
**×━━━━━━━━━━━━━━━━━━━━━×**
**🔰Host/IP:** `{DOMAIN}`
**🔰Username:** `{user.strip()}`
**🔰Password:** `{pw.strip()}`
**×━━━━━━━━━━━━━━━━━━━━━×**
**🌀OpenSSH:** `22`
**🌀SSL/TLS:** `445`, `777`, `443`
**🌀Ssh Udp:** `1-65535`
**🌀Ssh Ohp:** `8181`
**🌀Dropbear Ohp:** `8282`
**🌀OpenVpn Ohp:** `8383`
**🌀Dropbear:** `109`,`143`
**🌀WS SSL:** `443`
**🌀WS HTTP:** `80`
**🌀Squid:** `8080`, `3128`
**🌀UDPGW :** `7100-7300`
**×━━━━━━━━━━━━━━━━━━━━━×**
**🍀Payload Ssh Ws🍀**
`GET / HTTP/1.1 [crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**×━━━━━━━━━━━━━━━━━━━━━×**
**🍀File OpenVPN🍀**
__{DOMAIN}:89/udp.ovpn__
__{DOMAIN}:89/ssl.ovpn__
__{DOMAIN}:89/tcp.ovpn__
**×━━━━━━━━━━━━━━━━━━━━━×**
**🗓Expiry:** `{later}`
**×━━━━━━━━━━━━━━━━━━━━━×**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'unlockbg'))
async def unlock_ssh(event):
	async def unlock_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**🔸Username to unlock:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | unlockssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Unlock** (`{user}`)")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)
		
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'cekssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def ren_vmess(event):
	async def ren_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**🔸Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**🔸Masa Aktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" {exp}| renewssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**{a}**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ren_vmess_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" Trial ","trial-ssh"),
Button.inline(" Create ","create-ssh")],
[Button.inline(" Delete ","delete-ssh"),
Button.inline(" Cek Login ","login-ssh")],
[Button.inline(" Member ","show-ssh"),
Button.inline(" Renew ","renew-ssh")],
[Button.inline(" Lock User ","lockbg"),
Button.inline(" Unlock User ","unlockbg")],
[Button.inline("‹ Back Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**•━━━━━━━━━━━━━━━━━•**
**» 🔵Protocol:** __SSH OVPN__
**» 🔵Domain:** __{DOMAIN}__
**» 🔵ISP:** __{z["isp"]}__
**» 🔵Country:** __{z["country"]}__
**•━━━━━━━━━━━━━━━━━•**
**( menu ssh & openvpn )**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)