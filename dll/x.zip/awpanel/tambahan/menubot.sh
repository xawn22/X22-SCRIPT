#!/bin/bash
source /etc/os-release
IPVPS=$(curl -s ipinfo.io/ip )
exp=$(curl -sS https://permission.stn-cloud.my.id/check/database.ip | grep $IPVPS | awk '{print $3}')
name=$(curl -sS https://permission.stn-cloud.my.id/check/database.ip | grep $IPVPS | awk '{print $2}')
d1=$(date -d "$exp" +%s)
d2=$(date -d "$today" +%s)
useram=$( free -m | awk 'NR==2 {print $3}' )
totalram=$( free -m | awk 'NR==2 {print $2}' )
domain=$(cat /etc/xray/domain)
ssh=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)
trojanws=$(grep -E "^### " "/etc/trojan-go/akun.conf" | cut -d ' ' -f 2-3 | column -t | sort | uniq | wc -l)
vmess=$(grep -E "^### " "/etc/xray/config.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq | wc -l)
vless=$(grep -E "^#&&# " "/etc/xray/config.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq | wc -l)
uptimesvr="$(uptime -p | cut -d " " -f 2-10)"
echo "◆━━━━━━━━━━━━━━━━━━━━━━━━━◆"
echo "   <<⭐PANEL SERVER CONTROLLER⭐>>"
echo "◆━━━━━━━━━━━━━━━━━━━━━━━━━◆"
echo "🔰DOMAIN   : $domain"
echo "🔰OS NAME : $NAME $VERSION_ID"
echo "🔰MY IP        : $IPVPS"
echo "🔰EXPIRY     : $exp | $(((d1 - d2) / 86400)) Day"
echo "🔰MY RAM   : $totalram Mb / $useram Mb"
echo "🔰CLIENT     : $name"
echo "◆━━━━━━━━━━━━━━━━━━━━━━━━━◆"
echo "🌀SSH OVPN  : $ssh Account"
echo "🌀TROJAN      : $trojanws Account"
echo "🌀VMESS        : $vmess Account"
echo "🌀VLESS         : $vless Account"
echo "◆━━━━━━━━━━━━━━━━━━━━━━━━━◆"
echo "⏳Uptime : $uptimesvr"
echo "🤖Bot @WaanSuka_Turu"