from awpanel import *
from importlib import import_module
from awpanel.modules import ALL_MODULES
for module_name in ALL_MODULES:
        imported_module = import_module("awpanel.modules." + module_name)
bot.run_until_disconnected()

